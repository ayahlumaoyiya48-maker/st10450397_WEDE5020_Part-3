// =============================================
// SLIME APPAREL - COMPATIBLE JAVASCRIPT
// =============================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('🎯 Slime Apparel JavaScript loaded successfully!');
    
    // Initialize core functionality
    initMobileMenu();
    setActiveNavLink();
    initSmoothScroll();
    
    // Initialize page-specific features
    setTimeout(() => {
        try {
            initFormValidation();
            initAccordions();
            initSearchFunctionality();
            
            // Only initialize cart on pages that need it
            if (document.querySelector('.product-card')) {
                initCartFunctionality();
            }
            
            initImageLightbox();
        } catch (error) {
            console.error('Error initializing some features:', error);
        }
    }, 100);
});

// MOBILE MENU FUNCTIONALITY
function initMobileMenu() {
    const nav = document.querySelector('nav ul');
    if (!nav) return;
    
    // Remove existing mobile button to prevent duplicates
    const existingBtn = document.querySelector('.mobile-menu-btn');
    if (existingBtn) {
        existingBtn.remove();
    }
    
    // Create mobile menu button
    const mobileBtn = document.createElement('button');
    mobileBtn.className = 'mobile-menu-btn';
    mobileBtn.innerHTML = '☰';
    mobileBtn.setAttribute('aria-label', 'Toggle navigation menu');
    document.body.appendChild(mobileBtn);
    
    // Toggle menu function
    function toggleMenu() {
        const isVisible = nav.style.display === 'flex';
        nav.style.display = isVisible ? 'none' : 'flex';
    }
    
    // Event listeners
    mobileBtn.addEventListener('click', toggleMenu);
    
    // Close menu when clicking on links (mobile only)
    document.querySelectorAll('nav a').forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth <= 768) {
                nav.style.display = 'none';
            }
        });
    });
    
    // Handle window resize
    let resizeTimeout;
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(() => {
            if (window.innerWidth > 768) {
                nav.style.display = 'flex';
                mobileBtn.style.display = 'none';
            } else {
                mobileBtn.style.display = 'block';
                nav.style.display = 'none';
            }
        }, 250);
    });
    
    // Initial setup
    if (window.innerWidth <= 768) {
        mobileBtn.style.display = 'block';
        nav.style.display = 'none';
    } else {
        mobileBtn.style.display = 'none';
        nav.style.display = 'flex';
    }
}

// SHOPPING CART FUNCTIONALITY
function initCartFunctionality() {
    console.log('🛒 Initializing cart functionality...');
    
    let cart = JSON.parse(localStorage.getItem('slimeCart')) || [];
    
    // Remove existing cart button to prevent duplicates
    const existingCartBtn = document.querySelector('.cart-btn');
    if (existingCartBtn) {
        existingCartBtn.remove();
    }
    
    // Create cart button
    const cartBtn = document.createElement('button');
    cartBtn.className = 'cart-btn';
    cartBtn.innerHTML = `🛒 Cart (${cart.length})`;
    document.body.appendChild(cartBtn);
    
    // Update cart count
    function updateCartCount() {
        const cart = JSON.parse(localStorage.getItem('slimeCart')) || [];
        cartBtn.innerHTML = `🛒 Cart (${cart.length})`;
    }
    
    // Add to cart function
    function addToCart(product) {
        let cart = JSON.parse(localStorage.getItem('slimeCart')) || [];
        cart.push(product);
        localStorage.setItem('slimeCart', JSON.stringify(cart));
        updateCartCount();
        showNotification(`"${product.name}" added to cart!`, 'success');
    }
    
    // Setup add to cart buttons
    function setupAddToCartButtons() {
        const productCards = document.querySelectorAll('.product-card');
        
        productCards.forEach((card, index) => {
            // Remove existing buttons
            const existingBtns = card.querySelectorAll('.add-to-cart-btn');
            existingBtns.forEach(btn => btn.remove());
            
            // Create new button
            const addToCartBtn = document.createElement('button');
            addToCartBtn.className = 'add-to-cart-btn';
            addToCartBtn.textContent = 'Add to Cart';
            
            // Add click event
            addToCartBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                const productName = card.querySelector('h3')?.textContent || `Product ${index + 1}`;
                const productPrice = card.querySelector('.price')?.textContent || 'R0';
                const productImage = card.querySelector('img')?.src || '';
                
                addToCart({
                    name: productName,
                    price: productPrice,
                    image: productImage
                });
            });
            
            card.appendChild(addToCartBtn);
        });
    }
    
    // Show cart modal
    function showCart() {
        const cart = JSON.parse(localStorage.getItem('slimeCart')) || [];
        
        // Create modal
        const cartModal = document.createElement('div');
        cartModal.className = 'cart-modal';
        
        cartModal.innerHTML = `
            <div class="cart-modal-content">
                <h2>Your Cart</h2>
                ${cart.length === 0 ? '<p>Your cart is empty</p>' : ''}
                <div class="cart-items">
                    ${cart.map((item, index) => `
                        <div class="cart-item">
                            <img src="${item.image}" alt="${item.name}">
                            <div class="cart-item-info">
                                <h4>${item.name}</h4>
                                <p>${item.price}</p>
                            </div>
                            <button class="remove-item" data-index="${index}">Remove</button>
                        </div>
                    `).join('')}
                </div>
                ${cart.length > 0 ? `
                    <div class="cart-actions">
                        <button id="checkout-btn">Proceed to Checkout</button>
                    </div>
                ` : ''}
                <button id="close-cart">×</button>
            </div>
        `;
        
        document.body.appendChild(cartModal);
        
        // Close functionality
        document.getElementById('close-cart').addEventListener('click', function() {
            cartModal.remove();
        });
        
        cartModal.addEventListener('click', function(e) {
            if (e.target === cartModal) {
                cartModal.remove();
            }
        });
        
        // Remove items from cart
        cartModal.querySelectorAll('.remove-item').forEach(btn => {
            btn.addEventListener('click', function() {
                const index = parseInt(this.getAttribute('data-index'));
                let cart = JSON.parse(localStorage.getItem('slimeCart')) || [];
                if (index >= 0 && index < cart.length) {
                    cart.splice(index, 1);
                    localStorage.setItem('slimeCart', JSON.stringify(cart));
                    updateCartCount();
                    cartModal.remove();
                    showCart(); // Refresh cart
                }
            });
        });
        
        // Checkout button
        if (cart.length > 0) {
            document.getElementById('checkout-btn').addEventListener('click', function() {
                showNotification('Checkout functionality would redirect to payment processing!', 'info');
            });
        }
    }
    
    // Initialize
    setupAddToCartButtons();
    cartBtn.addEventListener('click', showCart);
    updateCartCount();
}

// SEARCH FUNCTIONALITY
function initSearchFunctionality() {
    const searchInput = document.getElementById('search-input');
    const searchBtn = document.getElementById('search-btn');
    const searchResults = document.getElementById('search-results');
    
    if (!searchInput || !searchBtn) return;
    
    function performSearch() {
        const query = searchInput.value.toLowerCase().trim();
        const productCards = document.querySelectorAll('.product-card');
        let foundResults = false;
        
        if (searchResults) {
            searchResults.innerHTML = '';
        }
        
        productCards.forEach(card => {
            const productName = card.querySelector('h3')?.textContent.toLowerCase() || '';
            const productDesc = card.querySelector('p')?.textContent.toLowerCase() || '';
            
            const isVisible = query === '' || productName.includes(query) || productDesc.includes(query);
            card.style.display = isVisible ? 'block' : 'none';
            
            if (isVisible) foundResults = true;
        });
        
        // Show no results message
        if (!foundResults && query !== '' && searchResults) {
            searchResults.innerHTML = `<p style="color: #666; text-align: center; padding: 20px;">No products found matching "${query}"</p>`;
        }
    }
    
    // Event listeners
    searchBtn.addEventListener('click', performSearch);
    searchInput.addEventListener('keyup', function(e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });
}

// FORM VALIDATION
function initFormValidation() {
    const contactForm = document.getElementById('contact-form');
    const enquiryForm = document.getElementById('enquiry-form');
    
    function validateForm(form) {
        let isValid = true;
        const requiredFields = form.querySelectorAll('input[required], select[required], textarea[required]');
        
        requiredFields.forEach(field => {
            const value = field.value.trim();
            let fieldValid = true;
            
            // Clear previous errors
            field.classList.remove('error');
            const existingError = field.parentNode.querySelector('.error-message');
            if (existingError) {
                existingError.remove();
            }
            
            // Check if field is empty
            if (!value) {
                fieldValid = false;
            }
            
            // Check min length for text areas and inputs
            if (field.type === 'textarea' || field.type === 'text') {
                const minLength = field.getAttribute('minlength');
                if (minLength && value.length < parseInt(minLength)) {
                    fieldValid = false;
                }
            }
            
            // Check email format
            if (field.type === 'email' && value) {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(value)) {
                    fieldValid = false;
                }
            }
            
            if (!fieldValid) {
                isValid = false;
                field.classList.add('error');
                
                // Add error message
                const errorElement = document.createElement('span');
                errorElement.className = 'error-message';
                
                if (field.type === 'email' && value) {
                    errorElement.textContent = 'Please enter a valid email address';
                } else if (field.getAttribute('minlength')) {
                    errorElement.textContent = `This field requires at least ${field.getAttribute('minlength')} characters`;
                } else {
                    errorElement.textContent = 'This field is required';
                }
                
                field.parentNode.appendChild(errorElement);
            }
        });
        
        return isValid;
    }
    
    // Contact form validation
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            if (validateForm(this)) {
                showNotification('Message sent successfully! We will get back to you soon.', 'success');
                this.reset();
                
                // Clear error styles
                this.querySelectorAll('.error').forEach(field => {
                    field.classList.remove('error');
                });
                this.querySelectorAll('.error-message').forEach(error => {
                    error.remove();
                });
            }
        });
    }
    
    // Enquiry form validation
    if (enquiryForm) {
        enquiryForm.addEventListener('submit', function(e) {
            e.preventDefault();
            if (validateForm(this)) {
                showNotification('Enquiry submitted successfully! We will contact you shortly.', 'success');
                this.reset();
                
                // Clear error styles
                this.querySelectorAll('.error').forEach(field => {
                    field.classList.remove('error');
                });
                this.querySelectorAll('.error-message').forEach(error => {
                    error.remove();
                });
            }
        });
    }
}

// FAQ ACCORDION FUNCTIONALITY
function initAccordions() {
    const accordionHeaders = document.querySelectorAll('.accordion-header');
    
    accordionHeaders.forEach(header => {
        header.addEventListener('click', function() {
            const content = this.nextElementSibling;
            const isOpen = content.style.display === 'block';
            
            // Close all accordions
            document.querySelectorAll('.accordion-content').forEach(item => {
                item.style.display = 'none';
            });
            
            document.querySelectorAll('.accordion-header span').forEach(span => {
                span.textContent = '+';
            });
            
            // Open clicked accordion if it was closed
            if (!isOpen) {
                content.style.display = 'block';
                this.querySelector('span').textContent = '−';
            }
        });
    });
}

// ACTIVE NAVIGATION LINK
function setActiveNavLink() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('nav a');
    
    navLinks.forEach(link => {
        const linkPage = link.getAttribute('href');
        if (linkPage === currentPage || (currentPage === '' && linkPage === 'index.html')) {
            link.style.backgroundColor = 'rgba(255, 255, 255, 0.2)';
            link.style.fontWeight = 'bold';
        }
    });
}

// SMOOTH SCROLLING
function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const target = document.querySelector(targetId);
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// IMAGE LIGHTBOX
function initImageLightbox() {
    const productImages = document.querySelectorAll('.product-card img');
    
    productImages.forEach(img => {
        img.style.cursor = 'pointer';
        img.addEventListener('click', function() {
            openLightbox(this.src, this.alt);
        });
    });
    
    function openLightbox(src, alt) {
        const lightbox = document.createElement('div');
        lightbox.id = 'lightbox';
        lightbox.innerHTML = `
            <div style="position: relative; max-width: 90%; max-height: 90%;">
                <img src="${src}" alt="${alt}" style="max-width: 100%; max-height: 90vh; border-radius: 10px;">
                <button id="close-lightbox" style="position: absolute; top: -40px; right: 0; background: none; border: none; color: white; font-size: 2rem; cursor: pointer;">×</button>
            </div>
        `;
        
        document.body.appendChild(lightbox);
        
        // Close functionality
        document.getElementById('close-lightbox').addEventListener('click', closeLightbox);
        lightbox.addEventListener('click', function(e) {
            if (e.target === lightbox) closeLightbox();
        });
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') closeLightbox();
        });
    }
    
    function closeLightbox() {
        const lightbox = document.getElementById('lightbox');
        if (lightbox) {
            lightbox.remove();
        }
    }
}

// NOTIFICATION SYSTEM
function showNotification(message, type = 'info') {
    // Remove existing notification
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // Create new notification
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 300);
        }
    }, 3000);
}

// Add CSS animations for notifications
if (!document.querySelector('#notification-styles')) {
    const style = document.createElement('style');
    style.id = 'notification-styles';
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
    document.head.appendChild(style);
}

// ERROR HANDLING
window.addEventListener('error', function(e) {
    console.error('JavaScript Error:', e.error);
});

// PERFORMANCE OPTIMIZATION
let isInitialized = false;
function initializeOnIdle() {
    if (!isInitialized && 'requestIdleCallback' in window) {
        window.requestIdleCallback(() => {
            // Initialize non-critical features
            isInitialized = true;
        });
    }
}

// Initialize performance-friendly features
initializeOnIdle();